
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner input = new Scanner (System.in);
	    int grade = input.nextInt();
	    if (grade>95){
	        System.out.println("A+");
	    }
	    else if (grade>=90 ){
	        System.out.println("A");
	    }
	    else if (grade>=85){
	        System.out.println("B+");
	    }
	     else if (grade>=80){
	        System.out.println("B");
	    }
	     else if (grade>=75){
	        System.out.println("C+");
	    }
	     else if (grade>=70){
	        System.out.println("C");
	    }
	     else if (grade>=65){
	        System.out.println("D+");
	    }
	     else if (grade>=60){
	        System.out.println("D");
	    }
	    else{
	        System.out.println("Fail");
	    }
		
	}
}
