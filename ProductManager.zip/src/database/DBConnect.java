package database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
    public static Connection connect() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb", "root", "your_password");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}