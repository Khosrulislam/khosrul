package controller;

import database.DBConnect;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;
import java.time.LocalDate;

public class MainController {
    @FXML private TableView<?> productTable;
    @FXML private TableView<?> reportTable;
    @FXML private TextField productNameField;
    @FXML private DatePicker fromDate, toDate;

    private Connection conn;

    public void initialize() {
        conn = DBConnect.connect();
        // load product list into productTable
    }

    public void addProduct() {
        String name = productNameField.getText();
        try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO products(name) VALUES (?)")) {
            stmt.setString(1, name);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeProduct() {
        String name = productNameField.getText();
        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM products WHERE name=?")) {
            stmt.setString(1, name);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void searchReport() {
        LocalDate from = fromDate.getValue();
        LocalDate to = toDate.getValue();
        // SQL query for filtering between dates
    }
}